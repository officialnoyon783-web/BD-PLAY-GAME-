import { useState } from 'react'
import {
  Trophy, Swords, Wallet, UserRound, CalendarDays, Users, ChevronRight,
  Menu, X, ShieldCheck, Zap, CircleHelp, Clock3, MapPin, Search, Bell
} from 'lucide-react'

type Mode = 'SOLO' | 'DUO' | 'SQUAD' | 'CLASH SQUAD'
type Tournament = {
  id: number
  title: string
  mode: Mode
  map: string
  date: string
  entry: string
  prize: string
  slots: string
  status: string
}

const tournaments: Tournament[] = [
  { id: 1, title: 'Crimson Clash #01', mode: 'SQUAD', map: 'Bermuda', date: 'Today · 8:30 PM', entry: '৳20 / team', prize: '৳800', slots: '18/25 teams', status: 'Registration Open' },
  { id: 2, title: 'Solo Booyah Cup', mode: 'SOLO', map: 'Purgatory', date: 'Tomorrow · 4:00 PM', entry: 'Free', prize: '৳300', slots: '42/48 players', status: 'Registration Open' },
  { id: 3, title: 'Duo Rush Arena', mode: 'DUO', map: 'Kalahari', date: 'Tomorrow · 7:00 PM', entry: '৳10 / team', prize: '৳500', slots: '21/24 teams', status: 'Starting Soon' },
  { id: 4, title: 'Clash Squad Showdown', mode: 'CLASH SQUAD', map: 'Custom Room', date: 'Sat · 6:00 PM', entry: 'Free', prize: '৳400', slots: '6/8 teams', status: 'Registration Open' },
]

const modes = ['ALL', 'SOLO', 'DUO', 'SQUAD', 'CLASH SQUAD']

export default function App() {
  const [tab, setTab] = useState('Tournaments')
  const [filter, setFilter] = useState('ALL')
  const [selected, setSelected] = useState<Tournament | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [notice, setNotice] = useState('')
  const [search, setSearch] = useState('')

  const nav = [
    { label: 'Tournaments', icon: Trophy },
    { label: 'My Matches', icon: CalendarDays },
    { label: 'Leaderboard', icon: Swords },
    { label: 'Wallet', icon: Wallet },
    { label: 'Profile', icon: UserRound },
  ]

  function notify(message: string) {
    setNotice(message)
    window.setTimeout(() => setNotice(''), 3000)
  }

  const visibleTournaments = tournaments.filter(t =>
    (filter === 'ALL' || t.mode === filter) &&
    t.title.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="icon-btn mobile-menu" aria-label="Toggle menu" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={21} /> : <Menu size={21} />}
        </button>
        <div className="brand-mark"><Swords size={23} strokeWidth={2.6} /></div>
        <div className="brand-copy">
          <div className="brand-name">BD PLAY <span>GAME</span></div>
          <div className="brand-tag">FREE FIRE TOURNAMENTS</div>
        </div>
        <div className="top-spacer" />
        <div className="demo-pill"><span /> DEMO PREVIEW</div>
        <button className="profile-chip" onClick={() => setTab('Profile')}><UserRound size={17} /><span>Player</span></button>
      </header>

      {menuOpen && <div className="mobile-menu-panel">{nav.map(item => <button key={item.label} onClick={() => { setTab(item.label); setMenuOpen(false) }}><item.icon size={18}/>{item.label}</button>)}</div>}

      <div className="layout">
        <aside className="sidebar">
          <div className="side-label">PLAYER HUB</div>
          {nav.map(item => (
            <button key={item.label} className={`nav-item ${tab === item.label ? 'active' : ''}`} onClick={() => setTab(item.label)}>
              <item.icon size={18} /><span>{item.label}</span>{tab === item.label && <ChevronRight size={16} className="nav-chevron" />}
            </button>
          ))}
          <div className="sidebar-bottom">
            <div className="mini-shield"><ShieldCheck size={18}/></div>
            <div><strong>Play fair. Compete hard.</strong><small>Community tournament hub</small></div>
          </div>
        </aside>

        <main className="main-content">
          {tab === 'Tournaments' ? <>
            <section className="hero">
              <div className="hero-copy">
                <div className="eyebrow"><Zap size={13} fill="currentColor"/> BANGLADESH ESPORTS</div>
                <h1>YOUR NEXT<br/><span>BOOYAH</span> STARTS HERE.</h1>
                <p>Find your squad. Enter the arena. Make your mark.</p>
                <button className="primary-btn" onClick={() => document.getElementById('tournament-list')?.scrollIntoView({ behavior: 'smooth' })}>Explore Tournaments <ChevronRight size={17}/></button>
              </div>
              <div className="hero-art" aria-hidden="true">
                <div className="art-ring ring-one" /><div className="art-ring ring-two" />
                <div className="art-swords"><Swords size={108} strokeWidth={1.3}/></div>
                <div className="art-badge">BD<br/><small>ESPORTS</small></div>
                <div className="art-spark spark-one">✦</div><div className="art-spark spark-two">✦</div>
              </div>
              <div className="hero-bottom"><span><span className="live-dot"/> COMMUNITY HUB</span><span>PLAY · COMPETE · WIN</span></div>
            </section>

            <section className="stats-grid">
              <div className="stat-card"><div className="stat-icon red"><Trophy size={19}/></div><div><small>ACTIVE TOURNAMENTS</small><strong>04</strong></div></div>
              <div className="stat-card"><div className="stat-icon gold"><Users size={19}/></div><div><small>PLAYERS REGISTERED</small><strong>128</strong></div></div>
              <div className="stat-card"><div className="stat-icon green"><Wallet size={19}/></div><div><small>TOTAL PRIZE POOL</small><strong>৳2,000</strong></div></div>
            </section>

            <section className="section-heading" id="tournament-list">
              <div><div className="eyebrow">FIND YOUR MATCH</div><h2>Featured Tournaments <span className="count">04</span></h2></div>
              <label className="search-box"><Search size={16}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search tournaments"/></label>
            </section>
            <div className="filter-row">{modes.map(mode => <button key={mode} className={`filter-chip ${filter === mode ? 'selected' : ''}`} onClick={() => setFilter(mode)}>{mode}</button>)}</div>

            <div className="tournament-grid">
              {visibleTournaments.map(t => <article className="tournament-card" key={t.id}>
                <div className={`tournament-banner banner-${t.id}`}>
                  <span className="mode-tag">{t.mode}</span><span className="banner-symbol"><Swords size={43}/></span>
                  <span className="status-tag"><i/> {t.status}</span>
                </div>
                <div className="tournament-body">
                  <h3>{t.title}</h3>
                  <div className="map-line"><MapPin size={14}/>{t.map}<span>•</span><Clock3 size={14}/>{t.date}</div>
                  <div className="card-metrics"><div><small>ENTRY FEE</small><strong>{t.entry}</strong></div><div><small>PRIZE POOL</small><strong className="prize">{t.prize}</strong></div></div>
                  <div className="card-footer"><span><Users size={14}/>{t.slots}</span><button onClick={() => setSelected(t)}>View Details <ChevronRight size={15}/></button></div>
                </div>
              </article>)}
            </div>
          </> : <section className="placeholder-page">
            <div className="placeholder-icon">{nav.find(n => n.label === tab)?.icon && (() => { const Icon = nav.find(n => n.label === tab)!.icon; return <Icon size={32}/> })()}</div>
            <div className="eyebrow">BD PLAY GAME</div>
            <h1>{tab}</h1>
            {tab === 'Wallet' ? <p>This is a demo preview. Real deposits, withdrawals, and balances require a secure backend and verified payment workflow.</p>
              : tab === 'Profile' ? <p>Player profile and Free Fire UID registration will be connected to authentication in the production version.</p>
              : tab === 'My Matches' ? <p>Your registered matches will appear here after account and tournament registration are connected.</p>
              : <p>Leaderboard data is sample content for the preview. Connect a backend before using real tournament results.</p>}
            <button className="primary-btn" onClick={() => setTab('Tournaments')}>Browse Tournaments <ChevronRight size={17}/></button>
          </section>}
        </main>
      </div>

      <nav className="bottom-nav">{nav.map(item => <button key={item.label} className={tab === item.label ? 'active' : ''} onClick={() => setTab(item.label)}><item.icon size={19}/><span>{item.label}</span></button>)}</nav>

      {selected && <div className="modal-backdrop" onClick={() => setSelected(null)}>
        <section className="modal" onClick={e => e.stopPropagation()}>
          <button className="modal-close icon-btn" aria-label="Close details" onClick={() => setSelected(null)}><X size={20}/></button>
          <div className="eyebrow">TOURNAMENT DETAILS</div><h2>{selected.title}</h2>
          <div className="modal-badges"><span>{selected.mode}</span><span>{selected.map}</span><span>{selected.status}</span></div>
          <div className="modal-info"><div><small>START TIME</small><strong>{selected.date}</strong></div><div><small>ENTRY</small><strong>{selected.entry}</strong></div><div><small>PRIZE POOL</small><strong className="prize">{selected.prize}</strong></div><div><small>SLOTS</small><strong>{selected.slots}</strong></div></div>
          <p className="modal-note">Demo preview only. Player sign-in, real slot booking, room credentials, and payments are not connected yet.</p>
          <button className="primary-btn full-width" onClick={() => { setSelected(null); notify('Demo only: registration is not connected yet.') }}>Register for Tournament <ChevronRight size={17}/></button>
        </section>
      </div>}

      {notice && <div className="toast"><CircleHelp size={17}/>{notice}</div>}
      <footer className="footer"><span>© 2026 BD PLAY GAME</span><span>Community esports preview · Free Fire only</span></footer>
    </div>
  )
}