# BD PLAY GAME

A mobile-first React + TypeScript starter UI for a Free Fire tournament hub. It contains demo tournament data and interactive navigation. It is **not yet a production tournament or payment system**.

## Included
- Responsive dark/crimson esports UI
- Tournament cards and mode filters
- Navigation for matches, leaderboard, wallet and profile
- Demo-only registration interactions
- Vite production build configuration for Vercel
- No PUBG-related content

## Run locally
Install Node.js on a computer or use a compatible cloud development environment.

```bash
npm install
npm run dev
```

For a production build:

```bash
npm run build
```

Vite writes the deployable website to `dist/`.

## Deploy from an Android phone
1. Create/sign in to a GitHub account at https://github.com.
2. Create a repository named `bd-play-game`.
3. Upload the contents of this project folder (upload the files/folders, not the ZIP as a single file if you want Vercel to build it).
4. Visit https://vercel.com and sign in with GitHub.
5. Choose **Add New → Project**, import `bd-play-game`, and deploy.
6. Build settings should be detected automatically. If asked, use Build Command `npm run build` and Output Directory `dist`.
7. Open the generated Vercel URL on your phone and test it.

## WebIntoApp
1. Once the deployed Vercel URL works, visit https://www.webintoapp.com.
2. Choose its website-to-app option and enter the public URL.
3. Set the app name to `BD PLAY GAME`, add your icon, then follow the provider's current build instructions.
4. Test the APK before sharing it.

## Important production work still required
- This is a demo UI with sample tournament entries. It does not authenticate real users or save data to a shared backend.
- Do not treat demo wallet amounts or sample prize values as real money.
- Do not add a public/hardcoded admin PIN. Admin authorization must be verified server-side.
- Before using real users, add a backend such as Supabase, authentication, Row Level Security, server-side authorization, secure wallet ledger and audit logs.
- For Supabase frontend use, only the project URL and anon/public key belong in client configuration. Never expose the service-role key in browser code or GitHub.
- Payments are not implemented. Do not claim a payment or withdrawal succeeded without a verified provider/backend flow.
